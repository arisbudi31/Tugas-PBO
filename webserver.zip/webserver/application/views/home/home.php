<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Web IoT</title>
    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.min.css ">
    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="lib/font-awesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="lib/style/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">

</head>

<body>
    <div class="container">
        <h1 class="text-center text-white" style="font-weight: 800">Demo Koneksi Arduino dengan Web</h1>
        <div class="row my-5">
            <div class="col-sm-3">
                <div class="card border-dark">
                    <div class="card-body card-height">
                        <i class="fas fa-4x fa-thermometer-half ml-2 my-3 text-danger"></i>
                        <div class="d-inline my-3 float-right">
                            <span class="aktual text-danger">25</span><sup class="text-danger">°C</sup>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body card-height">
                        <i class="fas fa-4x fa-tint ml-2 my-3 text-info"></i>
                        <div class="d-inline my-3 float-right">
                            <span class="aktual text-info">76</span><sup class="text-info">%</sup>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card card-height">
                    <div class="card-body mx-auto">
                        <span class="font-update text-secondary"> Terakhir update</span>
                        <div class="aktual mt-3 text-secondary mx-auto" style="font-size: 3rem ">
                            15:30
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body card-height">
                        <div class="control">
                            <i id="status_kipas" class="fas fa-6x fa-fan text-danger"></i>
                        </div>
                        <div>
                            <button id="kipas_on" class="btn btn-success btn-control">ON</button>
                            <button id="kipas_off" class="btn btn-danger btn-control">OFF</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo base_url(); ?>lib/jquery/jquery.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>lib/bootstrap/js/bootstrap.min.js"></script>
    <script>
        var server ="<?= base_url() ?>control";
        var access_key = "karangsong31";
        $("#kipas_on").on("click", function(){
            $ajax(
                {
                    async: true,
                    type: "get",
                    dataType: "json",
                    url: server,
                    data: {set: access_key, kipas_1: "1"},
                    success: function(response){
                        $("#status_kipas").css("color", "green");
                    } 
                }
            )
        });

        $("#kipas_off").on("click", function(){
            $ajax(
                {
                    async: true,
                    type: "get",
                    dataType: "json",
                    url: server,
                    data: {set: access_key, kipas_1: "0"},
                    success: function(response){} 
                }
            )
        });

        setInterval(function(){
            $ajax(
                {
                    async: true,
                    type: "get",
                    dataType: "json",
                    url: server,
                    data: {get: access_key},
                    success: function(response){
                        if(responese!="0"){
                            if(response.kipas_1=="1"){
                                $("#status_kipas").css("color", "green");
                            }
                        }
                    } 
                }
            )
        }, 10);
    </script>
</body>

</html>