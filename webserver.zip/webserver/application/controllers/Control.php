<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Control_model");
        $this->load->helper("server");
    }
    

    public function index()
    {
        if(isset($_GET["set"])==true && isset($_GET["kipas_1"]==true)){
            if($_GET["set"]== get_access_key()){
                $this->control_model->id ="data_1";
                if($this->control_model->exist_id()==true){
                    $this->control_model->kipas_1 = $_GET["kipas_1"];
                    $this->control_model->update();
                    echo "1";
                }
                else{
                    echo "0";
                }
            }
            else{
                echo "0";
            }
        }
    }

}

/* End of file Controllername.php */
