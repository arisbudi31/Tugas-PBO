<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Logs extends CI_Controller {
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('datalog');
    }
    

    public function index()
    {
        
    }

    public function getData(){
        if(!empty($_POST['hum'])&&!empty($_POST['suhu'])){
            $data['suhu'] = $_POST['suhu'];
            $data['hum']= $_POST['hum'];
            $data['time']= date("H:i:s");
            $this->datalog->insertData($data);
        }
        else{
            $this->session->set_flashdata('error_msg', 'Data tidak terdefinisi');
        }

    }

    public function tampilData(){
        $data= $this->datalog->showData();

        $this->load-view('home/home', $data);
    }
}

/* End of file Logs.php */