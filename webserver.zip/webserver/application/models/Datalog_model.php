<?php

defined('BASEPATH') OR exit('No direct script access allowed'); //model untuk simpan data sensor ke database

class Datalog_model extends CI_Model {
    
    public function getData(){
        if(!empty($_POST['hum'])&&!empty($_POST['suhu'])){
            $data['suhu'] = $_POST['suhu'];
            $data['hum']= $_POST['hum'];
            $data['time']= date("H:i:s");
            $this->datalog->insertData($data);
        }
        else{
            $this->session->set_flashdata('error_msg', 'Data tidak terdefinisi');
        }

    }

    public function tampilData(){
        $data= $this->datalog->showData();

        $this->load-view('home/home', $data);
    }

    public function update(){ //update data dari sensor
        $this->db->query("UPDATE data_sensor SET id=? ")
    }
}
