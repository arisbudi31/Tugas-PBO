<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control_model extends CI_Model {

    
    public function __construct()
    {
        parent::__construct();
        $this->load->helper("server");
        
    }

    public function updateControl(){ //update nilai kontrol pada web
        $this->db->query("UPDATE data_control SET id=?, kipas_1=?, WHERE id=BINARY ?", [$this->id, $this->kipas_1]);
    }

    public function exist_id(){
       $query =  $this->db->query("SELECT * FROM data_control WHERE id=BINARY ?", $this->id);
        if($query->num_rows()>0){
            $row=$query->row_array(0);
            $this->id = $row["id"];
            $this->kipas_1 = $row["kipas_1"];
            return true;
        }
        else{
            $this->id = "";
            $this->kipas_1 = "";
            return false;
        }
    }
    

}

/* End of file ModelName.php */
