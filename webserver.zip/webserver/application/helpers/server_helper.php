<?php

defined('BASEPATH') OR exit('No direct script access allowed');

function get_access_key(){
    return "karangsong31";
}